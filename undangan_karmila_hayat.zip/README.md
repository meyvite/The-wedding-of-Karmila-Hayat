# Undangan Pernikahan Karmila & Hayat

Selamat datang di undangan pernikahan digital **Karmila & Hayat**.

Kami mengundang Bapak/Ibu/Saudara/i untuk hadir dan berbagi kebahagiaan bersama kami dalam acara pernikahan yang Insya Allah akan diselenggarakan pada:

**Hari/Tanggal:** Minggu, 01 Juni 2025  
**Waktu:** 10.00 - 14.00 WIB  
**Tempat:** Gedung Graha Sativa Bulog, Bandung

---

## Fitur Undangan
- Tampilan modern & mobile friendly
- Informasi lengkap acara
- Lokasi dengan tautan ke Google Maps
- Form RSVP online
- Kutipan Islami yang menyentuh hati

---

## Akses Undangan
Silakan klik link berikut untuk melihat undangan digital kami:  
[https://namakamu.github.io/undangan-karmila-hayat](https://namakamu.github.io/undangan-karmila-hayat)

---

**Terima kasih atas doa dan restunya.**  
Salam hangat,  
**Karmila & Hayat**
